import dns.resolver
import requests
from requests.exceptions import ConnectionError, Timeout
import tkinter as tk
class SubdomainEnumerator:
    def __init__(self, subdomain_list_file, gui):
        self.subdomain_list_file = subdomain_list_file
        self.dns_resolver = dns.resolver.Resolver()
        self.gui = gui 

    def enumerate_subdomains(self, domain):
        found_subdomains = set()

        with open(self.subdomain_list_file, 'r') as file:
            subdomain_list = file.read().splitlines()

        for sub in subdomain_list:
            subdomain = f"{sub}.{domain}"

            try:
                answers = self.dns_resolver.resolve(subdomain, 'A')

                try:
                    response = requests.get(f"http://{subdomain}", timeout=5)
                    if response.status_code == 200:
                        found_subdomains.add(subdomain)
                        self.gui.txt_enum_output.insert(tk.END, subdomain + "\n") 
                except Timeout:
                    print(f"Timeout while querying {subdomain}.")
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
                pass
            except ConnectionError:
                pass
            except dns.resolver.Timeout:
                print(f"Timeout while resolving DNS for {subdomain}.")
            except Exception as e:
                print(f"An error occurred: {e}")

        return list(found_subdomains)