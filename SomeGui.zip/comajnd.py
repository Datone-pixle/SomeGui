import nmap3
from enum import Enum

class ScanType(Enum):
    QUICK_SCAN = 'Quick Scan'
    INTENSE_SCAN = 'Intense'
    FULL_SCAN = 'Full'
class NetworkScanner:
    def __init__(self):
        self.nmap = nmap3.Nmap()



    def perform_scan(self, target, scan_type):
        if scan_type == ScanType.QUICK_SCAN:
            return self.nmap.scan_top_ports(target)
        elif scan_type == ScanType.INTENSE_SCAN:
            return self.nmap.nmap_version_detection(target)
        elif scan_type == ScanType.FULL_SCAN:
            return self.nmap.nmap_os_detection(target)
        elif scan_type == ScanType.TCP_SCAN:
            return self.nmap.tcp_scan(target)
        elif scan_type == ScanType.UDP_SCAN:
            return self.nmap.udp_scan(target)
        else:
            raise ValueError("Invalid Scan Type")


    @staticmethod
    def format_scan_results(scan_results):
        if not isinstance(scan_results, dict):
            return "Unexpected scan result format. Results should be a dictionary."

        formatted_results = ""

        for target, data in scan_results.items():
            formatted_result = f"Results for target {target}:\n"
            if isinstance(data, bool):
                formatted_result += f"Unexpected data format for target {target}.\n"
            else:
                if 'ports' in data:
                    for port_info in data['ports']:
                        port = port_info['portid']
                        proto = port_info['protocol']
                        state = port_info['state']
                        service = port_info.get('service', {}).get('name', 'N/A')
                        formatted_result += f"\tPort : {port}/{proto}\tState : {state}\tService : {service}\n"
                else:
                    formatted_result += f"No port info for target {target}.\n"

                if 'hostname' in data:
                    for host_info in data['hostname']:
                        name = host_info.get('name')
                        if name:
                            formatted_result += f"\tHostname : {name}\n"

            formatted_results += formatted_result + "\n"

        return formatted_results