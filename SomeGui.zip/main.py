import tkinter as tk
from tkinter import ttk, messagebox
from sub import SubdomainEnumerator
from comajnd import NetworkScanner, ScanType
import threading

class CyberSecToolGUI(tk.Tk):
    def __init__(self):
        super().__init__()

        # Customize the GUI appearance for a hacker theme
        self.title("CyberSec Hacking Toolkit")
        self.geometry("900x700")
        self.configure(bg='black')

        # Customize tabs
        style = ttk.Style(self)
        style.theme_create("hacker_theme", parent="alt", settings={
            "TNotebook": {"configure": {"tabmargins": [2, 5, 2, 0]}},
            "TFrame": {"configure": {"background": "black"}},
            "TNotebook.Tab": {
                "configure": {"padding": [5, 1], "background": "black", "foreground": "green"},
                "map": {"background": [("selected", "green")]}
            }
        })
        style.theme_use("hacker_theme")

        # Create tabs, menu, and status bar
        self.tab_control = ttk.Notebook(self)
        self.create_tabs()
        self.create_status_bar()
        self.create_menu()

        subdomain_list_path = "nu11secur1ty.txt"
        self.subdomain_enumerator = SubdomainEnumerator("nu11secur1ty.txt", self)

    def create_menu(self):
        self.menu_bar = tk.Menu(self, bg='black', fg='green', border=0)

        file_menu = tk.Menu(self.menu_bar, tearoff=0, bg='black', fg='green')
        file_menu.add_command(label="Exit", command=self.quit)

        tools_menu = tk.Menu(self.menu_bar, tearoff=0, bg='black', fg='green')
        tools_menu.add_command(label="Subdomain Enumeration", command=lambda: self.tab_control.select(self.subdomain_tab))
        tools_menu.add_command(label="Network Scanning", command=lambda: self.tab_control.select(self.scanner_tab))

        help_menu = tk.Menu(self.menu_bar, tearoff=0, bg='black', fg='green')
        help_menu.add_command(label="About")

        self.menu_bar.add_cascade(label="File", menu=file_menu)
        self.menu_bar.add_cascade(label="Tools", menu=tools_menu)
        self.menu_bar.add_cascade(label="Help", menu=help_menu)

        self.config(menu=self.menu_bar)

    def create_tabs(self):
        self.subdomain_tab = ttk.Frame(self.tab_control)
        self.scanner_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.subdomain_tab, text='Subdomain Enumeration')
        self.tab_control.add(self.scanner_tab, text='Network Scanning')
        self.tab_control.pack(expand=1, fill="both")

        # Customize the appearance of individual tabs
        style = ttk.Style(self)
        style.configure('Black.TLabelframe.Label', foreground='lime', background='black')
        style.configure('Black.TLabelframe', background='black')
        style.configure('Black.TButton', foreground='lime', background='black')
        style.configure('Black.TLabel', foreground='lime', background='black')

        self.lbl_domain = ttk.Label(self.subdomain_tab, text="Enter Domain:", style='Black.TLabel')
        self.lbl_domain.pack(pady=(20, 0))
        self.entry_domain = ttk.Entry(self.subdomain_tab, foreground="green", background="black")
        self.entry_domain.pack(pady=(0, 10))
        self.btn_enum = ttk.Button(self.subdomain_tab, text="Enumerate", command=self.run_subdomain_enumeration, style='Black.TButton')
        self.btn_enum.pack()
        self.txt_enum_output = tk.Text(self.subdomain_tab, height=20, width=90, bg="black", fg="lime")
        self.txt_enum_output.pack(pady=(10, 0))

        self.lbl_target = ttk.Label(self.scanner_tab, text="Enter IP/Hostname:", style='Black.TLabel')
        self.lbl_target.pack(pady=(20, 0))
        self.entry_target = ttk.Entry(self.scanner_tab, foreground="green", background="black")
        self.entry_target.pack(pady=(0, 10))
        self.cmb_scan_type = ttk.Combobox(self.scanner_tab, values=[e.value for e in ScanType], state='readonly')
        self.cmb_scan_type.pack()
        self.cmb_scan_type.set('Quick Scan')
        self.btn_scan = ttk.Button(self.scanner_tab, text="Scan", command=self.run_network_scan, style='Black.TButton')
        self.btn_scan.pack()
        self.txt_scan_output = tk.Text(self.scanner_tab, height=20, width=90, bg="black", fg="lime")
        self.txt_scan_output.pack(pady=(10, 0))

    def create_status_bar(self):
        self.status_bar = tk.Label(self, text="Ready", bd=1, relief=tk.SUNKEN, anchor=tk.W, bg='black', fg='green')
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def run_subdomain_enumeration(self):
        domain = self.entry_domain.get().strip()

        if not domain:
            messagebox.showwarning("Warning", "Please enter a valid domain.")
            return

        self.txt_enum_output.delete('1.0', tk.END)
        self.txt_enum_output.insert(tk.END, "Starting Subdomain Enumeration... Please wait.\n")

        threading.Thread(target=self.enumeration_thread, args=(domain,)).start()

    def enumeration_thread(self, domain):
        self.btn_enum["state"] = "disabled"
        self.btn_scan["state"] = "disabled"

        subdomain_enumerator = SubdomainEnumerator("nu11secur1ty.txt", self) 
        found_subdomains = subdomain_enumerator.enumerate_subdomains(domain)

        self.txt_enum_output.delete('1.0', tk.END)
        for subdomain in found_subdomains:
            self.txt_enum_output.insert(tk.END, subdomain + "\n")

        self.btn_enum["state"] = "normal"
        self.btn_scan["state"] = "normal"

    def run_network_scan(self):
        target = self.entry_target.get().strip()
        scan_type_str = self.cmb_scan_type.get()  

        try:
            scan_type = next(e for e in ScanType if e.value.upper() == scan_type_str.upper())
        except StopIteration:
            messagebox.showerror("Error", "Invalid scan type selected.")
            return

        if not target:
            messagebox.showwarning("Warning", "Please enter a valid IP or hostname.")
            return

        self.txt_scan_output.delete('1.0', tk.END)
        self.txt_scan_output.insert(tk.END, "Starting Network Scan... Please wait.\n")

        threading.Thread(target=self.scanning_thread, args=(target, scan_type)).start()

    def scanning_thread(self, target, scan_type):
        self.btn_enum["state"] = "disabled"
        self.btn_scan["state"] = "disabled"
        self.network_scanner = NetworkScanner()
        results = self.network_scanner.perform_scan(target, scan_type)
        scan_output = self.network_scanner.format_scan_results(results) 

        self.txt_scan_output.delete('1.0', tk.END)
        self.txt_scan_output.insert(tk.END, scan_output)

        self.btn_enum["state"] = "normal"
        self.btn_scan["state"] = "normal"

app = CyberSecToolGUI()
app.mainloop()
